script_dir=$(dirname "$0")

# 在脚本所在目录中执行 hello.py 文件
python "$script_dir/start.py"